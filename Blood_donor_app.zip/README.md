# Blood Donor App

This is a simple Blood Donor Management System built with Next.js and React.

## How to Run
1. Install dependencies: `npm install`
2. Start development server: `npm run dev`

## Features
- Add donors
- View donor list

More features coming soon!
