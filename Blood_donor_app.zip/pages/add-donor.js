import { useState } from 'react';

export default function AddDonor() {
  const [name, setName] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    alert(`Donor Added: ${name}, Blood Group: ${bloodGroup}`);
  };

  return (
    <div>
      <h1>Add a New Donor</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required />
        <input type="text" placeholder="Blood Group" value={bloodGroup} onChange={(e) => setBloodGroup(e.target.value)} required />
        <button type="submit">Add Donor</button>
      </form>
    </div>
  );
}