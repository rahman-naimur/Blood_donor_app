import Head from 'next/head';
import Navbar from '../components/Navbar';

export default function Home() {
  return (
    <div>
      <Head>
        <title>Blood Donor App</title>
      </Head>
      <Navbar />
      <main>
        <h1>Welcome to Blood Donor Management System</h1>
      </main>
    </div>
  );
}